# PosePerfect Mat™ Research Notes

## Product Overview
- **Name:** PosePerfect Mat™ by Chris Headshots
- **Brand:** PosePerfect Mat (under Fail Up Inc.)
- **Price:** $54.99 (Sale from $99.99)
- **Key Features:**
    - Reduce session time (10 min -> 2 min per person).
    - Color-coded footprint guides.
    - Anti-slip backing.
    - Durable (1000+ sessions).
    - Unbranded option available.

## Target Audience (Initial)
- Volume photographers (schools, sports, corporate).
- Headshot photographers.
- Family reunion/Photobooth organizers.
- Content creators.

## Competitors
- **Pixapro Posing Mat (PiXAPOSE):** Similar footprint guide, rubber-backed, polyester.
- **Denny Mfg Volume Photography Posing Mat:** 3x13 foot vinyl guide with markers.
- **Strike a Pose Posing Mat (Etsy):** 18"x24" heavy duty mat.
- **DIY Solutions:** Tape on floor, white hardboard panels, plexiglass.

## Customer Pain Points
- Awkward posing direction ("step left", "move back").
- Wasted time in group/volume sessions.
- Inconsistent results across different subjects.
- Physical strain of directing many people.

## Voice of Customer (Initial)
- "Game-changer for family reunions."
- "Saves 10 minutes of awkward posing direction."
- "Rolls up tight and packs light."
- "Probably overpriced, but still worth it."

## Research Gaps to Fill
- Specific Reddit/Forum threads for deeper qualitative data (need to bypass or find alternative ways to read).
- TikTok/Instagram engagement analysis (why do their reels work?).
- Detailed pricing/offer comparison of competitors.
- SEO/AEO specific keyword volume and clusters.
