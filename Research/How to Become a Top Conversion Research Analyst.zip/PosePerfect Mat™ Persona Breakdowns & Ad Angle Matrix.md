# PosePerfect Mat™ Persona Breakdowns & Ad Angle Matrix

## Persona 1: The Volume Professional (High Efficiency)
- **Demographics:** Age 30-50, Male/Female, Professional Photographer.
- **Psychographics:** Values time, efficiency, and consistent output. Stressed by large crowds (schools, sports teams).
- **Use Case:** Shooting 100+ students or athletes in a single day.
- **Objections:** "Is it durable enough for 1000 kids?", "Will it slide on gym floors?", "Price is high for a mat."
- **Messaging:** "Cut your session time by 75%. Consistency at scale."

## Persona 2: The High-End Headshot Artist (Premium Experience)
- **Demographics:** Age 25-45, Male/Female, Boutique Studio Owner.
- **Psychographics:** Values client experience, precision, and personal brand. Wants to look like an expert.
- **Use Case:** One-on-one corporate headshots or actor portfolios.
- **Objections:** "Does it look professional in my studio?", "Will it help my clients feel more confident?", "Is there an unbranded version?"
- **Messaging:** "The secret to confident, photogenic clients. Professional gear for professional results."

## Persona 3: The Event/Photobooth Organizer (Ease of Use)
- **Demographics:** Age 20-40, Event Planner or DIY Enthusiast.
- **Psychographics:** Wants things to be 'idiot-proof'. Stressed by chaotic group photos at weddings or reunions.
- **Use Case:** Family reunions, weddings, corporate events with a photobooth.
- **Objections:** "Is it easy to set up?", "Can kids use it?", "Will it get dirty easily?"
- **Messaging:** "Flawless group photos, no direction needed. The 'idiot-proof' guide to perfect poses."

## Ad Angle Matrix

| Persona | Hook | Emotional Driver | Visual Composition | CTA |
| :--- | :--- | :--- | :--- | :--- |
| **Volume Pro** | "Stop wasting 15 mins per group." | Relief from chaos. | Split screen: Chaos vs. Order. | "Speed up your workflow." |
| **Headshot Artist** | "The secret to photogenic clients." | Confidence in expertise. | Close-up of client smiling on mat. | "Elevate your studio." |
| **Event Organizer** | "No more 'step left, step right'." | Joy of simplicity. | Time-lapse of a fast-moving line. | "Make your event perfect." |
| **Content Creator** | "The gear your studio is missing." | Desire for 'pro' look. | Aesthetic studio flat-lay. | "Get the mat." |
| **Junior/School** | "Wrangling kids just got easier." | Patience/Sanity. | Teacher/Photographer smiling with kids. | "Save your sanity." |
