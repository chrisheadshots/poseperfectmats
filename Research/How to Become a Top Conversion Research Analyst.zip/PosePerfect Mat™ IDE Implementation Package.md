# PosePerfect Mat™ IDE Implementation Package

## Project Structure Recommendation
- `/assets`: Brand logos, product images, mood board references.
- `/components`: Hero section, features grid, persona-specific sections, testimonial slider, FAQ accordion.
- `/pages`: `index.html` (Master), `volume-pro.html`, `headshot-artist.html`, `event-organizer.html`.
- `/styles`: Tailwind CSS config with brand colors (Yellow, Blue, Black).

## Key Components Specifications

### 1. Hero Section (Master)
- **Headline:** "Flawless Poses in 2 Minutes or Less."
- **Subheadline:** "The PosePerfect Mat™ eliminates awkward posing direction and cuts session time by 75%. Used by 5,000+ photographers worldwide."
- **Visual:** Video loop of a photographer using the mat vs. a chaotic session without it.
- **CTA:** "Shop the Collection - Save 45% Today."

### 2. Feature Grid (Benefit-First)
- **Feature:** Color-Coded Guides -> **Benefit:** No more "step left, step right."
- **Feature:** Anti-Slip Backing -> **Benefit:** Safety and stability on any floor.
- **Feature:** Studio-Grade Durability -> **Benefit:** One investment for 1,000+ shoots.
- **Feature:** Unbranded Option -> **Benefit:** Maintain your premium studio aesthetic.

### 3. Persona Landing Page: The Volume Pro
- **Hero Message:** "Wrangle the Crowd with Precision."
- **Imagery:** High-action shots of school or sports team sessions.
- **Proof:** "I shot 150 kids in 3 hours thanks to this mat." - Verified User.
- **Traffic Source:** Facebook Groups for Volume Photographers, PPA Forums.

### 4. Offer Stack Recommendations
- **The Starter:** 1x PosePerfect Mat ($54.99).
- **The Studio Bundle:** 1x Branded + 1x Unbranded + 1x Junior ($149.99 - Save 20%).
- **The Pro Expansion:** 5x Mats for large teams ($225.00 - Save 30%).
- **Bonus:** Free "Posing Guide PDF" with every purchase.

## CRO Recommendations
- **Sticky Cart:** Keep the "Add to Cart" button visible on mobile.
- **Exit-Intent Popup:** "Don't leave without your Posing Guide! (Plus 10% off your first mat)."
- **Social Proof:** Live "Verified Purchase" notifications.
- **Comparison Table:** PosePerfect Mat vs. DIY Tape vs. Competitors.
